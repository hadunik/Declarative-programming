# Revision history for AnGeo package

## 0.1.2.2 -- 2020-12-14

* file AnGeao.cabal: deleted restricion "&& <4.13" in the build-depends section

## 0.1.2.1 -- 2020-12-10

* (~~) to (–)
* some grammar mistakes

## 0.1.2.0 -- 2019-12-04

* Changes (many changes...)

## 0.1.1.0 -- 2018-12-12

* Some fixes

## 0.1.0.0 -- 2018-12-11

* changed ..OrSecs in function names into ..OrSeg
* added more comments in AnGeo.lhs
* fixed some errs in LinesPlanes.lhs, added some code


## 0.1.0.0 -- 2018-12-11

* First version. Released on an unsuspecting world.
